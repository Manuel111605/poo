/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package poo.dominio;

import java.util.Date;

public class ActaElectoral {
    private int idActa;
    private Date fechaHora;
    private String lugar;
    private Voto[] votos;
    private int totalVotos;

    public ActaElectoral(int idActa, Date fechaHora, String lugar, int maxVotos) {
        this.idActa = idActa;
        this.fechaHora = fechaHora;
        this.lugar = lugar;
        this.votos = new Voto[maxVotos];
        this.totalVotos = 0;
    }

    public void registrarVoto(Voto v) {
        if (totalVotos < votos.length) {
            votos[totalVotos++] = v;
            // Cada voto al registrarse incrementa el conteo del candidato
            v.registrar();
        }
    }

    // Métodos getters y otros que necesites...
} 
