/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package poo.dominio;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class Eleccion {
    private int id;
    private Date fecha;
    private String tipo;
    private Candidato[] candidatos;
    private int totalCandidatos;

    public Eleccion(int id, Date fecha, String tipo, int maxCandidatos) {
        this.id = id;
        this.fecha = fecha;
        this.tipo = tipo;
        this.candidatos = new Candidato[maxCandidatos];
        this.totalCandidatos = 0;
    }

    public int getId() { return id; }
    public Date getFecha() { return fecha; }
    public String getTipo() { return tipo; }

    public void agregarCandidato(Candidato c) {
        if (totalCandidatos < candidatos.length) {
            candidatos[totalCandidatos++] = c;
        }
    }

    public Candidato[] getCandidatos() { return candidatos; }

    public Map<Candidato, Integer> calcularResultados() {
        Map<Candidato, Integer> resultados = new HashMap<>();
        for (int i = 0; i < totalCandidatos; i++) {
            resultados.put(candidatos[i], 0);
        }
        // Sumar votos desde cada candidato
        for (int i = 0; i < totalCandidatos; i++) {
            Candidato c = candidatos[i];
            resultados.put(c, c.getVotos());
        }
        return resultados;
    }
}
