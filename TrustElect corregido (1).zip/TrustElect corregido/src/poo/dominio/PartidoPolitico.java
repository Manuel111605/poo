/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package poo.dominio;

/**
 *
 * @author solce
 */
public class PartidoPolitico {
    
    private String sigla;
    private String nombre;
    private String logo;
    private String representanteLegal;

    public PartidoPolitico(String sigla, String nombre, String logo, String representanteLegal) {
        this.sigla = sigla;
        this.nombre = nombre;
        this.logo = logo;
        this.representanteLegal = representanteLegal;
    }
}