/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package poo.ui;


import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

public class CandidatosPanel extends JPanel {
    public CandidatosPanel() {
        setLayout(new BorderLayout(5,5));
        JPanel top = new JPanel();
        JButton btnNew = new JButton("Crear");
        JButton btnEdit = new JButton("Modificar");
        JButton btnDel = new JButton("Eliminar");
        top.add(btnNew); top.add(btnEdit); top.add(btnDel);
        add(top, BorderLayout.NORTH);

        String[] cols = {"DNI", "Nombres", "Apellidos", "Partido"};
        JTable table = new JTable(new DefaultTableModel(cols, 0));
        add(new JScrollPane(table), BorderLayout.CENTER);

        btnNew.addActionListener(e -> { /* pendiente de implementar */ });
        btnEdit.addActionListener(e -> { /* pendiente de implementar */ });
        btnDel.addActionListener(e -> { /* pendiente de implementar */ });
    }
}

