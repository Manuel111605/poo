/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package poo.ui;


import poo.servicio.ElectionService;
import poo.dominio.Candidato;
import poo.dominio.Eleccion;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.text.SimpleDateFormat;
import java.util.Map;

public class EleccionesPanel extends JPanel {
    private ElectionService service = new ElectionService();
    private DefaultTableModel model;
    private JTable table;

    public EleccionesPanel() {
        setLayout(new BorderLayout(5,5));
        JPanel top = new JPanel();
        JButton btnNew = new JButton("Crear"), btnEdit = new JButton("Modificar"), btnDel = new JButton("Eliminar"), btnCount = new JButton("Contar Votos");
        top.add(btnNew); top.add(btnEdit); top.add(btnDel); top.add(btnCount);
        add(top, BorderLayout.NORTH);

        model = new DefaultTableModel(new String[]{"DNI","Fecha","Tipo"},0);
        table = new JTable(model);
        add(new JScrollPane(table), BorderLayout.CENTER);

        btnNew.addActionListener(e -> {
            CreateElectionDialog dlg = new CreateElectionDialog(SwingUtilities.getWindowAncestor(this));
            dlg.setVisible(true);
            if (dlg.isCreado()) {
                Eleccion e1 = dlg.getEleccion();
                service.crearEleccion(e1);
                model.addRow(new Object[]{e1.getId(), new SimpleDateFormat("dd/MM/yyyy").format(e1.getFecha()), e1.getTipo()});
            }
        });
        btnCount.addActionListener(e -> {
            int idx = table.getSelectedRow();
            if (idx < 0) {
                JOptionPane.showMessageDialog(this, "Seleccione una elección", "Atención", JOptionPane.WARNING_MESSAGE);
                return;
            }
            Eleccion sel = service.listarElecciones().get(idx);
            Map<Candidato,Integer> res = sel.calcularResultados();
            StringBuilder sb = new StringBuilder("Resultados:\n");
            res.forEach((c,v) -> sb.append(c.getDni()).append(" - ").append(v).append("\n"));
            JOptionPane.showMessageDialog(this, sb.toString(), "Conteo de Votos", JOptionPane.INFORMATION_MESSAGE);
        });
    }
}