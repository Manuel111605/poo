/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package poo.ui;

import javax.swing.*;
import java.awt.*;

public class MainFrame extends JFrame {
    public MainFrame() {
        setTitle("TrustElect - Dashboard"); setExtendedState(JFrame.MAXIMIZED_BOTH);
        setDefaultCloseOperation(EXIT_ON_CLOSE); initUI();
    }
    private void initUI() {
        JTabbedPane tabs = new JTabbedPane();
        tabs.addTab("Elecciones", new EleccionesPanel());
        tabs.addTab("Candidatos", new CandidatosPanel());
        tabs.addTab("Actas", new ActasPanel());
        tabs.addTab("Mesas", new MesasPanel());
        tabs.add("Miembros", new MiembrosPanel());
        tabs.addTab("Partidos", new PartidosPanel());
        tabs.addTab("Conteo & Reportes", new ReportesPanel());
        add(createMenuBar(), BorderLayout.NORTH);
        add(tabs, BorderLayout.CENTER);
    }
    private JMenuBar createMenuBar() {
        JMenuBar mb=new JMenuBar(); JMenu mF=new JMenu("Archivo");
        JMenuItem miLogout=new JMenuItem("Cerrar sesión"); miLogout.addActionListener(e->{ new LoginFrame().setVisible(true); dispose(); });
        JMenuItem miExit=new JMenuItem("Salir"); miExit.addActionListener(e->System.exit(0));
        mF.add(miLogout); mF.addSeparator(); mF.add(miExit); mb.add(mF); return mb;
    }
}