/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package poo.ui;



import javax.swing.*;
import java.awt.*;

public class ReportesPanel extends JPanel {
    public ReportesPanel() {
        setLayout(new BorderLayout(5,5));
        JTextArea area = new JTextArea("Generación de informes...");
        area.setEditable(false);
        add(new JScrollPane(area), BorderLayout.CENTER);

        // pendiente de implementar generación de informes detallados
    }
}