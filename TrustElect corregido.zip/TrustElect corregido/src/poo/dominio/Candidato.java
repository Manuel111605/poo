/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package poo.dominio;

/**
 *
 * @author solce
 */
public class Candidato {
    private String dni;
    private String nombres;
    private String apellidos;
    private PartidoPolitico partido;
    private int votos;

    public Candidato(String dni, String nombres, String apellidos, PartidoPolitico partido) {
        this.dni = dni;
        this.nombres = nombres;
        this.apellidos = apellidos;
        this.partido = partido;
        this.votos = 0;
    }

    public void agregarVotos(int cantidad) {
        this.votos += cantidad;
    }

    public int getVotos() { return votos; }

    // Getters necesarios para el conteo en la UI
    public String getDni() { return dni; }
    public String getNombres() { return nombres; }
}