/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package poo.dominio;

/**
 *
 * @author solce
 */
public class MesaElectoral {
    
private int idMesa;
    private MiembroMesa[] miembros;
    private int totalMiembros;

    public MesaElectoral(int idMesa, int maxMiembros) {
        this.idMesa = idMesa;
        this.miembros = new MiembroMesa[maxMiembros];
        this.totalMiembros = 0;
    }

    public void asignarMiembro(MiembroMesa m) {
        if (totalMiembros < miembros.length) {
            miembros[totalMiembros++] = m;
        }
    }
}

