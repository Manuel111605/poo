/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package poo.dominio;

public abstract class MiembroMesa {
    protected String dni;
    protected String nombres;
    protected String apellidos;
    protected String rol;

    public MiembroMesa(String dni, String nombres, String apellidos, String rol) {
        this.dni = dni;
        this.nombres = nombres;
        this.apellidos = apellidos;
        this.rol = rol;
    }
}