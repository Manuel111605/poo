/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package poo.dominio;

public class VocalMesa extends MiembroMesa {
    public VocalMesa(String dni, String nombres, String apellidos) {
        super(dni, nombres, apellidos, "Vocal");
    }
}
