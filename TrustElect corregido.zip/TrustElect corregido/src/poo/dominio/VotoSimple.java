/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package poo.dominio;

public class VotoSimple extends Voto {
    private Candidato candidato;

    public VotoSimple(Candidato candidato) {
        this.candidato = candidato;
    }

    @Override
    public void registrar() {
        // Incrementa un voto simple para el candidato
        candidato.agregarVotos(1);
    }
}
