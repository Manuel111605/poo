/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package poo.servicio;

public class AuthenticationService {
    public boolean login(String user, String pass) {
        return "admin".equals(user) && "1234".equals(pass);
    }
}