/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package poo.servicio;


import poo.dominio.Eleccion;
import java.util.List;
import java.util.ArrayList;

public class ElectionService {
    private List<Eleccion> elecciones = new ArrayList<>();
    public void crearEleccion(Eleccion e) { elecciones.add(e); }
    public List<Eleccion> listarElecciones() { return elecciones; }
}
