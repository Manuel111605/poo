/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package poo.ui;


import poo.dominio.Eleccion;
import javax.swing.*;
import java.awt.*;
import java.text.SimpleDateFormat;
import java.util.Date;

public class CreateElectionDialog extends JDialog {
    private JTextField txtId = new JTextField(10);
    private JTextField txtFecha = new JTextField(10);
    private JComboBox<String> cbTipo = new JComboBox<>(new String[]{"Municipal","Nacional","Referéndum"});
    private boolean creado = false;
    private Eleccion resultado;

    public CreateElectionDialog(Window owner) {
        super(owner, "Nueva Elección", ModalityType.APPLICATION_MODAL);
        setLayout(new GridLayout(4,2,5,5));
        add(new JLabel("DNI:")); add(txtId);
        add(new JLabel("Fecha (dd/MM/yyyy):")); add(txtFecha);
        add(new JLabel("Tipo:")); add(cbTipo);
        JButton btnOk = new JButton("Crear"), btnCancel = new JButton("Cancelar");
        btnOk.addActionListener(e -> onCrear()); btnCancel.addActionListener(e -> dispose());
        add(btnOk); add(btnCancel); pack(); setLocationRelativeTo(owner);
    }
    private void onCrear() {
        try {
            int id = Integer.parseInt(txtId.getText());
            Date fecha = new SimpleDateFormat("dd/MM/yyyy").parse(txtFecha.getText());
            String tipo = (String) cbTipo.getSelectedItem();
            resultado = new Eleccion(id, fecha, tipo, 10);
            creado = true; dispose();
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Datos inválidos: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    public boolean isCreado() { return creado; }
    public Eleccion getEleccion() { return resultado; }
}