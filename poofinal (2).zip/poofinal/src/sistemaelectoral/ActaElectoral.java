package sistemaelectoral;


public class ActaElectoral {
    private String numeroActa;
    private String fecha;
    private String hora;
    private MesaElectoral mesaElectoral;
    private int[] votosCandidatos;
    private int votosBlanco;
    private int votosNulos;
    private int totalVotos;
    private String observaciones;
    private boolean firmada;
    private String selloOficial;
    
    public ActaElectoral(String numeroActa, String fecha, String hora, MesaElectoral mesaElectoral, int numeroCandidatos) {
        this.numeroActa = numeroActa;
        this.fecha = fecha;
        this.hora = hora;
        this.mesaElectoral = mesaElectoral;
        this.votosCandidatos = new int[numeroCandidatos];
        this.votosBlanco = 0;
        this.votosNulos = 0;
        this.totalVotos = 0;
        this.observaciones = "";
        this.firmada = false;
        this.selloOficial = "";
    }
    
    public ActaElectoral() {
        this.numeroActa = "";
        this.fecha = "";
        this.hora = "";
        this.mesaElectoral = new MesaElectoral();
        this.votosCandidatos = new int[0];
        this.votosBlanco = 0;
        this.votosNulos = 0;
        this.totalVotos = 0;
        this.observaciones = "";
        this.firmada = false;
        this.selloOficial = "";
    }
    
    // Getters y Setters
    public String getNumeroActa() {
        return numeroActa;
    }
    
    public void setNumeroActa(String numeroActa) {
        this.numeroActa = numeroActa;
    }
    
    public String getFecha() {
        return fecha;
    }
    
    public void setFecha(String fecha) {
        this.fecha = fecha;
    }
    
    public String getHora() {
        return hora;
    }
    
    public void setHora(String hora) {
        this.hora = hora;
    }
    
    public MesaElectoral getMesaElectoral() {
        return mesaElectoral;
    }
    
    public void setMesaElectoral(MesaElectoral mesaElectoral) {
        this.mesaElectoral = mesaElectoral;
    }
    
    public int[] getVotosCandidatos() {
        return votosCandidatos;
    }
    
    public void setVotosCandidatos(int[] votosCandidatos) {
        this.votosCandidatos = votosCandidatos;
    }
    
    public int getVotosBlanco() {
        return votosBlanco;
    }
    
    public void setVotosBlanco(int votosBlanco) {
        this.votosBlanco = votosBlanco;
    }
    
    public int getVotosNulos() {
        return votosNulos;
    }
    
    public void setVotosNulos(int votosNulos) {
        this.votosNulos = votosNulos;
    }
    
    public int getTotalVotos() {
        return totalVotos;
    }
    
    public void setTotalVotos(int totalVotos) {
        this.totalVotos = totalVotos;
    }
    
    public String getObservaciones() {
        return observaciones;
    }
    
    public void setObservaciones(String observaciones) {
        this.observaciones = observaciones;
    }
    
    public boolean isFirmada() {
        return firmada;
    }
    
    public void setFirmada(boolean firmada) {
        this.firmada = firmada;
    }
    
    public String getSelloOficial() {
        return selloOficial;
    }
    
    public void setSelloOficial(String selloOficial) {
        this.selloOficial = selloOficial;
    }
    
    // Métodos específicos
    public void registrarVotoCandidato(int indiceCandidato, int votos) {
        if (indiceCandidato >= 0 && indiceCandidato < votosCandidatos.length) {
            votosCandidatos[indiceCandidato] = votos;
            calcularTotalVotos();
        }
    }
    
    public int obtenerVotosCandidato(int indiceCandidato) {
        if (indiceCandidato >= 0 && indiceCandidato < votosCandidatos.length) {
            return votosCandidatos[indiceCandidato];
        }
        return 0;
    }
    
    public void calcularTotalVotos() {
        totalVotos = votosBlanco + votosNulos;
        for (int votos : votosCandidatos) {
            totalVotos += votos;
        }
        
        mesaElectoral.setVotantesEfectivos(totalVotos);
    }
    
    public boolean validarActa() {
        return totalVotos <= mesaElectoral.getVotantesRegistrados() && 
               mesaElectoral.mesaCompleta() && 
               !numeroActa.isEmpty();
    }
    
    public void firmarActa() {
        if (validarActa()) {
            this.firmada = true;
            this.selloOficial = "ACTA_" + numeroActa + "_" + fecha.replace("/", "");
        }
    }
    
    public String generarResumen() {
        StringBuilder resumen = new StringBuilder();
        resumen.append("ACTA ELECTORAL N° ").append(numeroActa).append("\n");
        resumen.append("Fecha: ").append(fecha).append(" - Hora: ").append(hora).append("\n");
        resumen.append("Mesa: ").append(mesaElectoral.getNumeroMesa()).append(" - ").append(mesaElectoral.getLugar()).append("\n");
        resumen.append("Total de votos: ").append(totalVotos).append("\n");
        resumen.append("Votos en blanco: ").append(votosBlanco).append("\n");
        resumen.append("Votos nulos: ").append(votosNulos).append("\n");
        resumen.append("Estado: ").append(firmada ? "Firmada" : "Pendiente").append("\n");
        
        if (!observaciones.isEmpty()) {
            resumen.append("Observaciones: ").append(observaciones).append("\n");
        }
        
        return resumen.toString();
    }
    
    @Override
    public String toString() {
        return "Acta " + numeroActa + " - Mesa " + mesaElectoral.getNumeroMesa() + " (" + fecha + ")";
    }
}