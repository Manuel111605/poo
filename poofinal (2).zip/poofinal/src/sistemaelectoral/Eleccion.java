package sistemaelectoral;


public class Eleccion   {
    public enum TipoEleccion {
        MUNICIPAL, NACIONAL, REFERENDUM
    }
    
    private String nombre;
    private String fecha;
    private TipoEleccion tipoEleccion;
    private Candidato[] candidatos;
    private MesaElectoral[] mesasElectorales;
    private int numeroCandidatos;
    private int numeroMesas;
    private boolean activa;
    private boolean finalizada;
    
    // Constructor completo
    public Eleccion(String nombre, String fecha, TipoEleccion tipoEleccion, int maxCandidatos, int maxMesas) {
        this.nombre = nombre;
        this.fecha = fecha;
        this.tipoEleccion = tipoEleccion;
        this.candidatos = new Candidato[maxCandidatos];
        this.mesasElectorales = new MesaElectoral[maxMesas];
        this.numeroCandidatos = 0;
        this.numeroMesas = 0;
        this.activa = true;
        this.finalizada = false;
    }
    
    // Constructor vacío
    public Eleccion() {
        this.nombre = "";
        this.fecha = "";
        this.tipoEleccion = TipoEleccion.MUNICIPAL;
        this.candidatos = new Candidato[20]; 
        this.mesasElectorales = new MesaElectoral[50];
        this.numeroCandidatos = 0;
        this.numeroMesas = 0;
        this.activa = true;
        this.finalizada = false;
    }
    
    // Getters y Setters
    public String getNombre() {
        return nombre;
    }
    
    public void setFecha(String fecha) {
        this.fecha = fecha;
    }
    
    public TipoEleccion getTipoEleccion() {
        return tipoEleccion;
    }
    
    public void setTipoEleccion(TipoEleccion tipoEleccion) {
        this.tipoEleccion = tipoEleccion;
    }
    
    public Candidato[] getCandidatos() {
        return candidatos;
    }
    
    public void setCandidatos(Candidato[] candidatos) {
        this.candidatos = candidatos;
    }
    
    public MesaElectoral[] getMesasElectorales() {
        return mesasElectorales;
    }
    
    public void setMesasElectorales(MesaElectoral[] mesasElectorales) {
        this.mesasElectorales = mesasElectorales;
    }
    
    public int getNumeroCandidatos() {
        return numeroCandidatos;
    }
    
    public void setNumeroCandidatos(int numeroCandidatos) {
        this.numeroCandidatos = numeroCandidatos;
    }
    
    public int getNumeroMesas() {
        return numeroMesas;
    }
    
    public void setNumeroMesas(int numeroMesas) {
        this.numeroMesas = numeroMesas;
    }
    
    public boolean isActiva() {
        return activa;
    }
    
    public void setActiva(boolean activa) {
        this.activa = activa;
    }
    
    public boolean isFinalizada() {
        return finalizada;
    }
    
    public void setFinalizada(boolean finalizada) {
        this.finalizada = finalizada;
    }
    
    // Métodos específicos
    public boolean agregarCandidato(Candidato candidato) {
        if (numeroCandidatos < candidatos.length) {
            candidatos[numeroCandidatos] = candidato;
            numeroCandidatos++;
            return true;
        }
        return false;
    }
    
    public boolean eliminarCandidato(int indice) {
        if (indice >= 0 && indice < numeroCandidatos) {
            for (int i = indice; i < numeroCandidatos - 1; i++) {
                candidatos[i] = candidatos[i + 1];
            }
            candidatos[numeroCandidatos - 1] = null;
            numeroCandidatos--;
            return true;
        }
        return false;
    }
    
    public Candidato buscarCandidato(String dni) {
        for (int i = 0; i < numeroCandidatos; i++) {
            if (candidatos[i] != null && candidatos[i].getDni().equals(dni)) {
                return candidatos[i];
            }
        }
        return null;
    }
    
    public boolean agregarMesa(MesaElectoral mesa) {
        if (numeroMesas < mesasElectorales.length) {
            mesasElectorales[numeroMesas] = mesa;
            numeroMesas++;
            return true;
        }
        return false;
    }
    
    public boolean eliminarMesa(int numeroMesa) {
        for (int i = 0; i < numeroMesas; i++) {
            if (mesasElectorales[i] != null && mesasElectorales[i].getNumeroMesa() == numeroMesa) {
                for (int j = i; j < numeroMesas - 1; j++) {
                    mesasElectorales[j] = mesasElectorales[j + 1];
                }
                mesasElectorales[numeroMesas - 1] = null;
                numeroMesas--;
                return true;
            }
        }
        return false;
    }
    
    public MesaElectoral buscarMesa(int numeroMesa) {
        for (int i = 0; i < numeroMesas; i++) {
            if (mesasElectorales[i] != null && mesasElectorales[i].getNumeroMesa() == numeroMesa) {
                return mesasElectorales[i];
            }
        }
        return null;
    }
    
    public void calcularResultados() {
        for (int i = 0; i < numeroCandidatos; i++) {
            if (candidatos[i] != null) {
                candidatos[i].reiniciarVotos();
            }
        }
        
    }
    
    public int obtenerTotalVotantes() {
        int total = 0;
        for (int i = 0; i < numeroMesas; i++) {
            if (mesasElectorales[i] != null) {
                total += mesasElectorales[i].getVotantesRegistrados();
            }
        }
        return total;
    }
    
    public int obtenerTotalVotosEfectivos() {
        int total = 0;
        for (int i = 0; i < numeroMesas; i++) {
            if (mesasElectorales[i] != null) {
                total += mesasElectorales[i].getVotantesEfectivos();
            }
        }
        return total;
    }
    
    public double calcularPorcentajeParticipacion() {
        int totalVotantes = obtenerTotalVotantes();
        if (totalVotantes == 0) return 0.0;
        return (double) obtenerTotalVotosEfectivos() / totalVotantes * 100;
    }
    
    public Candidato obtenerGanador() {
        if (numeroCandidatos == 0) return null;
        
        Candidato ganador = candidatos[0];
        for (int i = 1; i < numeroCandidatos; i++) {
            if (candidatos[i] != null && candidatos[i].getVotosObtenidos() > ganador.getVotosObtenidos()) {
                ganador = candidatos[i];
            }
        }
        return ganador;
    }
    
    public String generarReporteResultados() {
        StringBuilder reporte = new StringBuilder();
        reporte.append("REPORTE DE RESULTADOS\n");
        reporte.append("Elección: ").append(nombre).append("\n");
        reporte.append("Fecha: ").append(fecha).append("\n");
        reporte.append("Tipo: ").append(tipoEleccion).append("\n");
        reporte.append("Participación: ").append(String.format("%.2f%%", calcularPorcentajeParticipacion())).append("\n\n");
        
        reporte.append("RESULTADOS POR CANDIDATO:\n");
        for (int i = 0; i < numeroCandidatos; i++) {
            if (candidatos[i] != null) {
                int totalVotos = obtenerTotalVotosEfectivos();
                double porcentaje = candidatos[i].calcularPorcentajeVotos(totalVotos);
                reporte.append(candidatos[i].getNombreCompleto())
                      .append(" (").append(candidatos[i].getPartidoPolitico().getSigla()).append("): ")
                      .append(candidatos[i].getVotosObtenidos())
                      .append(" votos (").append(String.format("%.2f%%", porcentaje)).append(")\n");
            }
        }
        
        return reporte.toString();
    }
    
    public void finalizarEleccion() {
        this.finalizada = true;
        this.activa = false;
        calcularResultados();
    }
    
    public void activarEleccion() {
        this.activa = true;
        this.finalizada = false;
    }
    
    @Override
    public String toString() {
        return nombre + " - " + fecha + " (" + tipoEleccion + ")";    }
}
