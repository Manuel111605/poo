
package sistemaelectoral;


public class Candidato extends Persona {
    private PartidoPolitico partidoPolitico;
    private int votosObtenidos;
    private int numeroLista;
    
    public Candidato(String nombre, String apellido, String dni, PartidoPolitico partidoPolitico, int numeroLista) {
        super(nombre, apellido, dni);
        this.partidoPolitico = partidoPolitico;
        this.numeroLista = numeroLista;
        this.votosObtenidos = 0;
    }
    
    public Candidato() {
        super();
        this.partidoPolitico = new PartidoPolitico();
        this.votosObtenidos = 0;
        this.numeroLista = 0;
    }
    
    @Override
    public String obtenerTipo() {
        return "Candidato";
    }
    
    @Override
    public String mostrarInformacion() {
        return "Candidato: " + getNombreCompleto() + " - DNI: " + getDni() + 
               " - Partido: " + partidoPolitico.getSigla() + " - Votos: " + votosObtenidos;
    }
    
    // Getters y Setters
    public PartidoPolitico getPartidoPolitico() {
        return partidoPolitico;
    }
    
    public void setPartidoPolitico(PartidoPolitico partidoPolitico) {
        this.partidoPolitico = partidoPolitico;
    }
    
    public int getVotosObtenidos() {
        return votosObtenidos;
    }
    
    public void setVotosObtenidos(int votosObtenidos) {
        this.votosObtenidos = votosObtenidos;
    }
    
    public int getNumeroLista() {
        return numeroLista;
    }
    
    public void setNumeroLista(int numeroLista) {
        this.numeroLista = numeroLista;
    }
    
    // Métodos 
    public void agregarVotos(int votos) {
        this.votosObtenidos += votos;
    }
    
    public void reiniciarVotos() {
        this.votosObtenidos = 0;
    }
    
    public double calcularPorcentajeVotos(int totalVotos) {
        if (totalVotos == 0) return 0.0;
        return (double) votosObtenidos / totalVotos * 100;
    }
    
    @Override
    public String toString() {
        return numeroLista + " - " + getNombreCompleto() + " (" + partidoPolitico.getSigla() + ")";
    }
}