package sistemaelectoral;


public class MesaElectoral {
    private int numeroMesa;
    private String lugar;
    private String direccion;
    private MiembroMesa[] miembros;
    private int votantesRegistrados;
    private int votantesEfectivos;
    private boolean activa;
    
    // Constructor completo
    public MesaElectoral(int numeroMesa, String lugar, String direccion, int votantesRegistrados) {
        this.numeroMesa = numeroMesa;
        this.lugar = lugar;
        this.direccion = direccion;
        this.votantesRegistrados = votantesRegistrados;
        this.votantesEfectivos = 0;
        this.miembros = new MiembroMesa[3]; // Presidente, Secretario, Vocal
        this.activa = true;
    }
    
    // Constructor vacío
    public MesaElectoral() {
        this.numeroMesa = 0;
        this.lugar = "";
        this.direccion = "";
        this.votantesRegistrados = 0;
        this.votantesEfectivos = 0;
        this.miembros = new MiembroMesa[3];
        this.activa = true;
    }
    
    // Getters y Setters
    public int getNumeroMesa() {
        return numeroMesa;
    }
    
    public void setNumeroMesa(int numeroMesa) {
        this.numeroMesa = numeroMesa;
    }
    
    public String getLugar() {
        return lugar;
    }
    
    public void setLugar(String lugar) {
        this.lugar = lugar;
    }
    
    public String getDireccion() {
        return direccion;
    }
    
    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }
    
    public MiembroMesa[] getMiembros() {
        return miembros;
    }
    
    public void setMiembros(MiembroMesa[] miembros) {
        this.miembros = miembros;
    }
    
    public int getVotantesRegistrados() {
        return votantesRegistrados;
    }
    
    public void setVotantesRegistrados(int votantesRegistrados) {
        this.votantesRegistrados = votantesRegistrados;
    }
    
    public int getVotantesEfectivos() {
        return votantesEfectivos;
    }
    
    public void setVotantesEfectivos(int votantesEfectivos) {
        this.votantesEfectivos = votantesEfectivos;
    }
    
    public boolean isActiva() {
        return activa;
    }
    
    public void setActiva(boolean activa) {
        this.activa = activa;
    }
    
    // Métodos específicos
    public boolean asignarMiembro(MiembroMesa miembro) {
        switch (miembro.getTipoMiembro()) {
            case PRESIDENTE:
                miembros[0] = miembro;
                return true;
            case SECRETARIO:
                miembros[1] = miembro;
                return true;
            case VOCAL:
                miembros[2] = miembro;
                return true;
            default:
                return false;
        }
    }
    
    public MiembroMesa obtenerMiembro(MiembroMesa.TipoMiembro tipo) {
        switch (tipo) {
            case PRESIDENTE:
                return miembros[0];
            case SECRETARIO:
                return miembros[1];
            case VOCAL:
                return miembros[2];
            default:
                return null;
        }
    }
    
    public boolean mesaCompleta() {
        return miembros[0] != null && miembros[1] != null && miembros[2] != null;
    }
    
    public int contarMiembrosPresentes() {
        int presentes = 0;
        for (MiembroMesa miembro : miembros) {
            if (miembro != null && miembro.isPresente()) {
                presentes++;
            }
        }
        return presentes;
    }
    
    public double calcularPorcentajeParticipacion() {
        if (votantesRegistrados == 0) return 0.0;
        return (double) votantesEfectivos / votantesRegistrados * 100;
    }
    
    public String obtenerInformacion() {
        return "Mesa N° " + numeroMesa + " - " + lugar + " - Votantes: " + 
               votantesEfectivos + "/" + votantesRegistrados;
    }
    
    @Override
    public String toString() {
        return "Mesa " + numeroMesa + " - " + lugar;
    }
}