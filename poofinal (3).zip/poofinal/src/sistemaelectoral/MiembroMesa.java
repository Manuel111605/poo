package sistemaelectoral;


public class MiembroMesa extends Persona {
    public enum TipoMiembro {
        PRESIDENTE, SECRETARIO, VOCAL
    }
    
    private TipoMiembro tipoMiembro;
    private boolean presente;
    
    public MiembroMesa(String nombre, String apellido, String dni, TipoMiembro tipoMiembro) {
        super(nombre, apellido, dni);
        this.tipoMiembro = tipoMiembro;
        this.presente = false;
    }
    
    public MiembroMesa() {
        super();
        this.tipoMiembro = TipoMiembro.VOCAL;
        this.presente = false;
    }
    
    @Override
    public String obtenerTipo() {
        return "Miembro de Mesa - " + tipoMiembro.toString();
    }
    
    @Override
    public String mostrarInformacion() {
        String estado = presente ? "Presente" : "Ausente";
        return "Miembro de Mesa: " + getNombreCompleto() + " - DNI: " + getDni() + 
               " - Cargo: " + tipoMiembro + " - Estado: " + estado;
    }
    
    public TipoMiembro getTipoMiembro() {
        return tipoMiembro;
    }
    
    public void setTipoMiembro(TipoMiembro tipoMiembro) {
        this.tipoMiembro = tipoMiembro;
    }
    
    public boolean isPresente() {
        return presente;
    }
    
    public void setPresente(boolean presente) {
        this.presente = presente;
    }
    
    public void marcarPresencia() {
        this.presente = true;
    }
    
    public void marcarAusencia() {
        this.presente = false;
    }
    
    public String obtenerCargoTexto() {
        switch (tipoMiembro) {
            case PRESIDENTE:
                return "Presidente de Mesa";
            case SECRETARIO:
                return "Secretario";
            case VOCAL:
                return "Vocal";
            default:
                return "Miembro";
        }
    }
    
    @Override
    public String toString() {
        return getNombreCompleto() + " - " + obtenerCargoTexto();
    }
}