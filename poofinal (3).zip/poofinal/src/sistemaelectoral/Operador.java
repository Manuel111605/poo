package sistemaelectoral;


public class Operador extends Persona {
    private String usuario;
    private String contraseña;
    private boolean activo;
    private String nivel; 
    
    public Operador(String nombre, String apellido, String dni, String usuario, String contraseña, String nivel) {
        super(nombre, apellido, dni);
        this.usuario = usuario;
        this.contraseña = contraseña;
        this.nivel = nivel;
        this.activo = true;
    }
    
    public Operador() {
        super();
        this.usuario = "";
        this.contraseña = "";
        this.nivel = "OPERADOR";
        this.activo = true;
    }
    
    @Override
    public String obtenerTipo() {
        return "Operador del Sistema - " + nivel;
    }
    
    @Override
    public String mostrarInformacion() {
        String estado = activo ? "Activo" : "Inactivo";
        return "Operador: " + getNombreCompleto() + " - Usuario: " + usuario + 
               " - Nivel: " + nivel + " - Estado: " + estado;
    }
    
    public String getUsuario() {
        return usuario;
    }
    
    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }
    
    public String getContraseña() {
        return contraseña;
    }
    
    public void setContraseña(String contraseña) {
        this.contraseña = contraseña;
    }
    
    public boolean isActivo() {
        return activo;
    }
    
    public void setActivo(boolean activo) {
        this.activo = activo;
    }
    
    public String getNivel() {
        return nivel;
    }
    
    public void setNivel(String nivel) {
        this.nivel = nivel;
    }
    
    public boolean validarCredenciales(String usuario, String contraseña) {
        return this.usuario.equals(usuario) && this.contraseña.equals(contraseña) && this.activo;
    }
    
    public boolean esAdministrador() {
        return "ADMINISTRADOR".equals(nivel);
    }
    
    public void cambiarContraseña(String nuevaContraseña) {
        this.contraseña = nuevaContraseña;
    }
    
    public void activarOperador() {
        this.activo = true;
    }
    
    public void desactivarOperador() {
        this.activo = false;
    }
    
    @Override
    public String toString() {
        return usuario + " - " + getNombreCompleto() + " (" + nivel + ")";
    }
}