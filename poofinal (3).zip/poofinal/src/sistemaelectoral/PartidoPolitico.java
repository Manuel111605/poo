package sistemaelectoral;


public class PartidoPolitico {
    private String nombre;
    private String sigla;
    private String representanteLegal;
    private String logo;
    
    public PartidoPolitico(String nombre, String sigla, String representanteLegal, String logo) {
        this.nombre = nombre;
        this.sigla = sigla;
        this.representanteLegal = representanteLegal;
        this.logo = logo;
    }
    
    public PartidoPolitico() {
        this.nombre = "";
        this.sigla = "";
        this.representanteLegal = "";
        this.logo = "";
    }
    
    public String getNombre() {
        return nombre;
    }
    
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    
    public String getSigla() {
        return sigla;
    }
    
    public void setSigla(String sigla) {
        this.sigla = sigla;
    }
    
    public String getRepresentanteLegal() {
        return representanteLegal;
    }
    
    public void setRepresentanteLegal(String representanteLegal) {
        this.representanteLegal = representanteLegal;
    }
    
    public String getLogo() {
        return logo;
    }
    
    public void setLogo(String logo) {
        this.logo = logo;
    }
    
    public String obtenerInformacion() {
        return "Partido: " + nombre + " (" + sigla + ") - Representante: " + representanteLegal;
    }
    
    @Override
    public String toString() {
        return sigla + " - " + nombre;
    }
}