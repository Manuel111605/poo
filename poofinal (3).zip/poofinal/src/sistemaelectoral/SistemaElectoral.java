package sistemaelectoral;


public class SistemaElectoral {
    private Eleccion[] elecciones;
    private PartidoPolitico[] partidos;
    private Operador[] operadores;
    private ActaElectoral[] actas;
    private Operador operadorActual;
    private int numeroElecciones;
    private int numeroPartidos;
    private int numeroOperadores;
    private int numeroActas;
    private boolean sistemaIniciado;
    
    public SistemaElectoral() {
        this.elecciones = new Eleccion[10]; 
        this.partidos = new PartidoPolitico[20]; 
        this.operadores = new Operador[10]; 
        this.actas = new ActaElectoral[500]; 
        this.numeroElecciones = 0;
        this.numeroPartidos = 0;
        this.numeroOperadores = 0;
        this.numeroActas = 0;
        this.sistemaIniciado = false;
        this.operadorActual = null;
        
        inicializarDatosPorDefecto();
    }
    
    // Getters y Setters
    public Eleccion[] getElecciones() {
        return elecciones;
    }
    
    public PartidoPolitico[] getPartidos() {
        return partidos;
    }
    
    public Operador[] getOperadores() {
        return operadores;
    }
    
    public ActaElectoral[] getActas() {
        return actas;
    }
    
    public Operador getOperadorActual() {
        return operadorActual;
    }
    
    public void setOperadorActual(Operador operadorActual) {
        this.operadorActual = operadorActual;
    }
    
    public int getNumeroElecciones() {
        return numeroElecciones;
    }
    
    public int getNumeroPartidos() {
        return numeroPartidos;
    }
    
    public int getNumeroOperadores() {
        return numeroOperadores;
    }
    
    public int getNumeroActas() {
        return numeroActas;
    }
    
    public boolean isSistemaIniciado() {
        return sistemaIniciado;
    }
    
    public void inicializarDatosPorDefecto() {
        Operador admin = new Operador("Admin", "Sistema", "12345678", "admin", "admin123", "ADMINISTRADOR");
        agregarOperador(admin);
        
        PartidoPolitico partido1 = new PartidoPolitico("Partido Nacional", "PN", "Juan Pérez", "logo_pn.png");
        PartidoPolitico partido2 = new PartidoPolitico("Alianza Popular", "AP", "María García", "logo_ap.png");
        PartidoPolitico partido3 = new PartidoPolitico("Movimiento Ciudadano", "MC", "Carlos López", "logo_mc.png");
        
        agregarPartido(partido1);
        agregarPartido(partido2);
        agregarPartido(partido3);
        
        sistemaIniciado = true;
    }
    

    public boolean autenticarOperador(String usuario, String contraseña) {
        for (int i = 0; i < numeroOperadores; i++) {
            if (operadores[i] != null && operadores[i].validarCredenciales(usuario, contraseña)) {
                operadorActual = operadores[i];
                return true;
            }
        }
        return false;
    }
    
    public void cerrarSesion() {
        operadorActual = null;
    }
    
    public boolean usuarioLogueado() {
        return operadorActual != null;
    }
    
    // Métodos para gestionar Operadores
    public boolean agregarOperador(Operador operador) {
        if (numeroOperadores < operadores.length) {
            operadores[numeroOperadores] = operador;
            numeroOperadores++;
            return true;
        }
        return false;
    }
    
    public boolean eliminarOperador(String usuario) {
        for (int i = 0; i < numeroOperadores; i++) {
            if (operadores[i] != null && operadores[i].getUsuario().equals(usuario)) {
                if (operadores[i].esAdministrador() && contarAdministradores() == 1) {
                    return false;
                }
                
                for (int j = i; j < numeroOperadores - 1; j++) {
                    operadores[j] = operadores[j + 1];
                }
                operadores[numeroOperadores - 1] = null;
                numeroOperadores--;
                return true;
            }
        }
        return false;
    }
    
    public Operador buscarOperador(String usuario) {
        for (int i = 0; i < numeroOperadores; i++) {
            if (operadores[i] != null && operadores[i].getUsuario().equals(usuario)) {
                return operadores[i];
            }
        }
        return null;
    }
    
    private int contarAdministradores() {
        int count = 0;
        for (int i = 0; i < numeroOperadores; i++) {
            if (operadores[i] != null && operadores[i].esAdministrador()) {
                count++;
            }
        }
        return count;
    }
    
    public boolean agregarPartido(PartidoPolitico partido) {
        if (numeroPartidos < partidos.length) {
            partidos[numeroPartidos] = partido;
            numeroPartidos++;
            return true;
        }
        return false;
    }
    
    public boolean eliminarPartido(String sigla) {
        for (int i = 0; i < numeroPartidos; i++) {
            if (partidos[i] != null && partidos[i].getSigla().equals(sigla)) {
                if (tieneCanditatosAsociados(partidos[i])) {
                    return false;
                }
                
                for (int j = i; j < numeroPartidos - 1; j++) {
                    partidos[j] = partidos[j + 1];
                }
                partidos[numeroPartidos - 1] = null;
                numeroPartidos--;
                return true;
            }
        }
        return false;
    }
    
    public PartidoPolitico buscarPartido(String sigla) {
        for (int i = 0; i < numeroPartidos; i++) {
            if (partidos[i] != null && partidos[i].getSigla().equals(sigla)) {
                return partidos[i];
            }
        }
        return null;
    }
    
    private boolean tieneCanditatosAsociados(PartidoPolitico partido) {
        for (int i = 0; i < numeroElecciones; i++) {
            if (elecciones[i] != null) {
                Candidato[] candidatos = elecciones[i].getCandidatos();
                for (int j = 0; j < elecciones[i].getNumeroCandidatos(); j++) {
                    if (candidatos[j] != null && candidatos[j].getPartidoPolitico().equals(partido)) {
                        return true;
                    }
                }
            }
        }
        return false;
    }
    
    public boolean agregarEleccion(Eleccion eleccion) {
        if (numeroElecciones < elecciones.length) {
            elecciones[numeroElecciones] = eleccion;
            numeroElecciones++;
            return true;
        }
        return false;
    }
    
    public boolean eliminarEleccion(String nombre) {
        for (int i = 0; i < numeroElecciones; i++) {
            if (elecciones[i] != null && elecciones[i].getNombre().equals(nombre)) {
                for (int j = i; j < numeroElecciones - 1; j++) {
                    elecciones[j] = elecciones[j + 1];
                }
                elecciones[numeroElecciones - 1] = null;
                numeroElecciones--;
                return true;
            }
        }
        return false;
    }
    
    public Eleccion buscarEleccion(String nombre) {
        for (int i = 0; i < numeroElecciones; i++) {
            if (elecciones[i] != null && elecciones[i].getNombre().equals(nombre)) {
                return elecciones[i];
            }
        }
        return null;
    }
    
    public boolean agregarActa(ActaElectoral acta) {
        if (numeroActas < actas.length) {
            actas[numeroActas] = acta;
            numeroActas++;
            return true;
        }
        return false;
    }
    
    public ActaElectoral buscarActa(String numeroActa) {
        for (int i = 0; i < numeroActas; i++) {
            if (actas[i] != null && actas[i].getNumeroActa().equals(numeroActa)) {
                return actas[i];
            }
        }
        return null;
    }
    
    public ActaElectoral[] obtenerActasPorMesa(int numeroMesa) {
        ActaElectoral[] actasMesa = new ActaElectoral[numeroActas];
        int contador = 0;
        
        for (int i = 0; i < numeroActas; i++) {
            if (actas[i] != null && actas[i].getMesaElectoral().getNumeroMesa() == numeroMesa) {
                actasMesa[contador] = actas[i];
                contador++;
            }
        }
        
        ActaElectoral[] resultado = new ActaElectoral[contador];
        for (int i = 0; i < contador; i++) {
            resultado[i] = actasMesa[i];
        }
        
        return resultado;
    }
    
    public void procesarVotosDeActas() {
        for (int i = 0; i < numeroElecciones; i++) {
            if (elecciones[i] != null && elecciones[i].isActiva()) {
                procesarVotosEleccion(elecciones[i]);
            }
        }
    }
    
    private void procesarVotosEleccion(Eleccion eleccion) {
        Candidato[] candidatos = eleccion.getCandidatos();
        for (int i = 0; i < eleccion.getNumeroCandidatos(); i++) {
            if (candidatos[i] != null) {
                candidatos[i].reiniciarVotos();
            }
        }
        
        for (int i = 0; i < numeroActas; i++) {
            if (actas[i] != null && actas[i].isFirmada()) {
                int[] votosCandidatos = actas[i].getVotosCandidatos();
                for (int j = 0; j < votosCandidatos.length && j < eleccion.getNumeroCandidatos(); j++) {
                    if (candidatos[j] != null) {
                        candidatos[j].agregarVotos(votosCandidatos[j]);
                    }
                }
            }
        }
    }
    
    public String generarReporteGeneral() {
        StringBuilder reporte = new StringBuilder();
        reporte.append("REPORTE GENERAL DEL SISTEMA ELECTORAL\n");
        reporte.append("=====================================\n\n");
        
        reporte.append("ESTADÍSTICAS GENERALES:\n");
        reporte.append("- Elecciones registradas: ").append(numeroElecciones).append("\n");
        reporte.append("- Partidos políticos: ").append(numeroPartidos).append("\n");
        reporte.append("- Operadores del sistema: ").append(numeroOperadores).append("\n");
        reporte.append("- Actas procesadas: ").append(numeroActas).append("\n\n");
        
        reporte.append("ELECCIONES ACTIVAS:\n");
        for (int i = 0; i < numeroElecciones; i++) {
            if (elecciones[i] != null && elecciones[i].isActiva()) {
                reporte.append("- ").append(elecciones[i].toString()).append("\n");
            }
        }
        
        return reporte.toString();
    }
    
    public String generarReportePorEleccion(String nombreEleccion) {
        Eleccion eleccion = buscarEleccion(nombreEleccion);
        if (eleccion != null) {
            return eleccion.generarReporteResultados();
        }
        return "Elección no encontrada";
    }
    
    public boolean validarIntegridadSistema() {
        if (contarAdministradores() == 0) {
            return false;
        }
        
        for (int i = 0; i < numeroActas; i++) {
            if (actas[i] != null && !actas[i].validarActa()) {
                return false;
            }
        }
        
        return true;
    }
    
    public void reiniciarSistema() {
        numeroElecciones = 0;
        numeroPartidos = 0;
        numeroActas = 0;
        
        Operador admin = null;
        for (int i = 0; i < numeroOperadores; i++) {
            if (operadores[i] != null && operadores[i].esAdministrador()) {
                admin = operadores[i];
                break;
            }
        }
        
        operadores = new Operador[10];
        numeroOperadores = 0;
        
        if (admin != null) {
            agregarOperador(admin);
        }
        
        elecciones = new Eleccion[10];
        partidos = new PartidoPolitico[20];
        actas = new ActaElectoral[500];
        
        inicializarDatosPorDefecto();
    }
    
    @Override
    public String toString() {
        return "Sistema Electoral - Elecciones: " + numeroElecciones + 
               ", Partidos: " + numeroPartidos + 
               ", Operadores: " + numeroOperadores;
    }
}