package sistemaelectoral;


public interface IValidacion {
    boolean validarDNI(String dni);
    boolean validarNombre(String nombre);
    boolean validarFecha(String fecha);
}