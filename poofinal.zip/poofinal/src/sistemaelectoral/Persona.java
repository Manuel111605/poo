package sistemaelectoral;


public abstract class Persona implements IValidacion{
    protected String nombre;
    protected String apellido;
    protected String dni;
    
    // Constructor
    public Persona(String nombre, String apellido, String dni) {
        this.nombre = nombre;
        this.apellido = apellido;
        this.dni = dni;
    }
    
    // Constructor vacío
    public Persona() {
        this.nombre = "";
        this.apellido = "";
        this.dni = "";
    }
    
    // Métodos abstractos
    public abstract String obtenerTipo();
    public abstract String mostrarInformacion();
    
    // Métodos concretos
    public String getNombre() {
        return nombre;
    }
    
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    
    public String getApellido() {
        return apellido;
    }
    
    public void setApellido(String apellido) {
        this.apellido = apellido;
    }
    
    public String getDni() {
        return dni;
    }
    
    public void setDni(String dni) {
        this.dni = dni;
    }
    
    public String getNombreCompleto() {
        return nombre + " " + apellido;
    }
    
    // Implementación de métodos de IValidacion
    @Override
    public boolean validarDNI(String dni) {
        return dni != null && dni.length() == 8 && dni.matches("\\d+");
    }
    
    @Override
    public boolean validarNombre(String nombre) {
        return nombre != null && !nombre.trim().isEmpty() && nombre.length() >= 2;
    }
    
    @Override
    public boolean validarFecha(String fecha) {
        // Validación básica de formato dd/mm/yyyy
        return fecha != null && fecha.matches("\\d{2}/\\d{2}/\\d{4}");
    }
}